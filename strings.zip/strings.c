#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MIN_STRING_LEN 4                     //macro to define string length
#define MAX_STRING_LEN 1024

int is_valid_char(char c)                      //function intializing
{
    return isprint(c) && !isspace(c);             //to print character and space between characters
}

void extract_strings(char *data, size_t len, int min_len)        //function instializing
{
    int i, j;                                                   //declaration of variables
    char *str = (char *) malloc(MAX_STRING_LEN);                //allocating dynamic memory to char pointer
    if (str == NULL)                                             //cond to check string is empty
    {
        perror("malloc failed");                                 //command to check error
        exit(EXIT_FAILURE);
    }
    for (i = 0; i < len; i++)                                      //loop to check upto string length
    {
        if (!is_valid_char(data[i])) {
            continue;
        }
        j = 0;
        while (is_valid_char(data[i + j]) && j < MAX_STRING_LEN - 1)
       	{
            str[j] = data[i + j];
            j++;
        }
        if (j >= min_len) 
	{
            str[j] = '\0';
            printf("%s\n", str);
        }
    }
    free(str);                                                   //empty string
}

int main(int argc, char *argv[])                             
{
    FILE *fp;                                                     //fetching from given file              
    char *data;                                                   
    size_t len;

    if (argc < 2)                                                 //to check argument count less than 2
    {
        printf("Usage: %s <binary file>\n", argv[0]);                   
        return EXIT_FAILURE;
    }

    fp = fopen(argv[1], "rb");                                       //to read the existing command
    if (fp == NULL) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    fseek(fp, 0, SEEK_END);
    len = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    data = (char *) malloc(len);
    if (data == NULL) {
        perror("malloc failed");
        return EXIT_FAILURE;
    }

    fread(data, 1, len, fp);
    fclose(fp);

    extract_strings(data, len, MIN_STRING_LEN);
    free(data);

    return EXIT_SUCCESS;
}

